import org.openpatch.scratch.*;

public class Spieler extends Sprite
{
    
    public Spieler()
    {
      this.addCostume("stehen", "Grafiken/Players/bunny1_stand.png");
    }
}
