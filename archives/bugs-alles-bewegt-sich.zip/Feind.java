import org.openpatch.scratch.*;

public class Feind extends Sprite
{
  
    public Feind()
    {
   
    }

}
